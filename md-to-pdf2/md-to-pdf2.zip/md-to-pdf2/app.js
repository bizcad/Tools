// Elements
const mdInput   = document.getElementById('mdInput');
const htmlPreview = document.getElementById('htmlPreview');
const fileInput = document.getElementById('fileInput');
const dropZone  = document.getElementById('dropZone');
const renderBtn = document.getElementById('renderBtn');
const exportBtn = document.getElementById('exportBtn');
const pdfIframe = document.getElementById('pdfIframe');

let currentMdFileName = 'document.md';

function renderMarkdownToHtml() {
  const md = mdInput.value || '';
  const html = marked.parse(md);
  htmlPreview.innerHTML = html;
}

fileInput.addEventListener('change', async (e) => {
  const file = e.target.files?.[0];
  if (!file) return;
  await loadMarkdownFile(file);
});

async function loadMarkdownFile(file) {
  currentMdFileName = file.name || 'document.md';
  const text = await file.text();
  mdInput.value = text;
  renderMarkdownToHtml();
}

['dragenter','dragover'].forEach(evt =>
  dropZone.addEventListener(evt, (e) => { e.preventDefault(); dropZone.classList.add('hover'); })
);
['dragleave','drop'].forEach(evt =>
  dropZone.addEventListener(evt, (e) => { e.preventDefault(); dropZone.classList.remove('hover'); })
);

dropZone.addEventListener('drop', async (e) => {
  const file = e.dataTransfer?.files?.[0];
  if (!file) return;
  await loadMarkdownFile(file);
});

mdInput.addEventListener('input', renderMarkdownToHtml);
renderBtn.addEventListener('click', renderMarkdownToHtml);

exportBtn.addEventListener('click', async () => {
  renderMarkdownToHtml();

  const baseName = (currentMdFileName || 'document.md').replace(/\.[^.]+$/, '') || 'document';
  const pdfName = `${baseName}.pdf`;

  const opt = {
    margin: 10,
    filename: pdfName,
    image: { type: 'jpeg', quality: 0.95 },
    html2canvas: { scale: 2, useCORS: true },
    jsPDF: { unit: 'pt', format: 'letter', orientation: 'portrait' },
    pagebreak: { mode: ['css','legacy'] }
  };

  const worker = html2pdf().from(htmlPreview).set(opt).toPdf();
  const pdf = await worker.get('pdf');
  const blob = pdf.output('blob');
  const blobUrl = URL.createObjectURL(blob);
  pdfIframe.src = blobUrl;
});

// Starter content
mdInput.value = `# Hello, Nick\n\nPaste Markdown on the left, then **Render HTML** or **Export to PDF**.`;
renderMarkdownToHtml();
